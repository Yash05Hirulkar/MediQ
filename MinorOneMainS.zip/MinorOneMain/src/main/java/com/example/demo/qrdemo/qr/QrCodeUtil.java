package com.example.demo.qrdemo.qr;


import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Date;

public class QrCodeUtil {

    public static String generateQRCode(String content, String email) throws WriterException, IOException {
        QRCodeWriter writer = new QRCodeWriter();
        BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, 300, 300);

        // Save to static/qrcodes folder
        Date data = new Date();
        String fileName = email + "_" + data.getTime() + ".png";
        String uploadDir = "src/main/resources/static/qrcodes/";
        Path path = FileSystems.getDefault().getPath(uploadDir + fileName);
        MatrixToImageWriter.writeToPath(matrix, "PNG", path);

        return "qrcodes/" + fileName;  // Relative path for web display
    }
}

