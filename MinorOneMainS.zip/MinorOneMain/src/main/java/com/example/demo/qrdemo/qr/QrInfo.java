package com.example.demo.qrdemo.qr;

public class QrInfo {
    
}
