package com.example.demo.Control;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Entities.Info;
import com.example.demo.Entities.Prescription;
import com.example.demo.repository.InfoRepository;
import com.example.demo.repository.PrescriptionRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class PatientController {
    @Autowired
    private PrescriptionRepository repository;

    @Autowired
    private InfoRepository infoRepository;

    @GetMapping("/showqr")
    public String viewQRCode(HttpSession session, Model model) {
        String email = (String) session.getAttribute("name");
        String name = (String) session.getAttribute("firstName");

        // Fetch all prescriptions for the patient
        List<Prescription> prescriptions = repository.findByEmail(email);

        if (!prescriptions.isEmpty()) {
            // Get the most recent (last) prescription
            Prescription prescription = prescriptions.get(prescriptions.size() - 1);

            // Add QR code path to the model
            LocalDateTime date = prescription.getDateOfExpiry();
            model.addAttribute("date", date);
            model.addAttribute("name", name);
            model.addAttribute("doctor", prescription.getDoctorName());
            model.addAttribute("qrPath", "/" + prescription.getQrCodePath());

            // Return the page that displays the QR code
            return "showqr";
        } else {
            // If no prescriptions are found, show an error page
            model.addAttribute("error", "No prescription found for this email.");
            return "petdash";
        }
    }

    @GetMapping("/showqrs")
    public String viewQRCodes(HttpSession session, Model model) {
        String email = (String) session.getAttribute("name");

        // Fetch all prescriptions for the patient
        Optional<Info> info = infoRepository.findById(email);

        if (!info.isEmpty()) {
            // Get the most recent (last) prescription
            Info info1 = info.get();

            // Add QR code path to the model
            model.addAttribute("qrPath", "/" + info1.getQrCodePath());

            // Return the page that displays the QR code
            return "showqr";
        } else {
            // If no prescriptions are found, show an error page
            model.addAttribute("error", "No prescription found for this email.");
            return "petdash";
        }
    }

    @PostMapping("/paitentshow")
    public String show1(@RequestParam("email") String email, Model model){
        Optional<Info> info = infoRepository.findById(email);
        if(!info.isEmpty()){
            Info i = info.get();
            String name = i.getEmail();
            name = name.substring(0, name.indexOf('@'));
            model.addAttribute("name", name.toUpperCase());
            model.addAttribute("qrPath", i.getQrCodePath());
            model.addAttribute("add",i.getDetails());
        return "paidoctQR";
        }
        else {
            // If no prescriptions are found, show an error page
            model.addAttribute("error", "No prescription found for this email.");
            return "dash";
        }
    }
}
