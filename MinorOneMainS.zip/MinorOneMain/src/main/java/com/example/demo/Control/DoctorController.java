package com.example.demo.Control;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Entities.Prescription;
import com.example.demo.qrdemo.qr.QrCodeUtil;
import com.example.demo.repository.PrescriptionRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class DoctorController {
    @Autowired
    private PrescriptionRepository repository;

    @PostMapping("/load")
    public String submitPrescription(@RequestParam("email") String email,
            @RequestParam("info") String prescriptionText,
            Model model, HttpSession session) throws Exception {

        String qrContent = "Prescription for: " + email + "\n" + prescriptionText;
        String qrPath = QrCodeUtil.generateQRCode(qrContent, email);
        String name = (String) session.getAttribute("firstName");

        Prescription prescription = new Prescription();
        prescription.setEmail(email);
        prescription.setPrescriptionText(prescriptionText);
        prescription.setQrCodePath(qrPath);
        prescription.setDoctorName(name);
        LocalDateTime date = LocalDateTime.now();
        // Convert LocalDateTime to java.sql.Date
        prescription.setDateOfIssue(date);
        prescription.setDateOfExpiry(date.plusMinutes(3)); // Set expiry date to 24 hours later
        // Save the prescription to the database
        repository.save(prescription);

        model.addAttribute("message", "Prescription submitted successfully.");
        return "dash";
    }
}
