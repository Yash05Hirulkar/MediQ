package com.example.demo.Handlers;

import java.io.IOException;

// import org.hibernate.validator.internal.util.stereotypes.Lazy;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;

import com.example.demo.services.UserService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class LogoutHandle implements LogoutSuccessHandler{

    private ApplicationContext applicationContext;

    public LogoutHandle(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
            throws IOException, ServletException {

        UserService userService = applicationContext.getBean(UserService.class);
        userService.deleevry(); // Call the method to delete expired prescriptions
        // Redirect to the login page after logout
        response.sendRedirect("/login");
        
    }
    
}
