package com.example.demo.repository;

import org.springframework.stereotype.Repository;

import com.example.demo.Entities.Info;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface InfoRepository extends JpaRepository<Info, String> {
    
    // For example, find by full name or any other field
    
}
