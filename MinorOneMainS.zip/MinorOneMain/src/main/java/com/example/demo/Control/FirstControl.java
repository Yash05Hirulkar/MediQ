package com.example.demo.Control;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.Optional;

import com.example.demo.repository.InfoRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import com.google.zxing.WriterException;
import jakarta.servlet.http.HttpSession;

import com.example.demo.Entities.Info;
import com.example.demo.Entities.User;
import com.example.demo.qrdemo.qr.QRCodeGenerator;
import com.example.demo.qrdemo.qr.QrCodeUtil;

@Controller
public class FirstControl {

    private String lastInput;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    private final UserRepository ur;

    @Autowired
    private final InfoRepository infoRepository;

    public FirstControl(PasswordEncoder passwordEncoder, UserRepository ur, InfoRepository infoRepository) {
        this.infoRepository = infoRepository;
        this.passwordEncoder = passwordEncoder;
        this.ur = ur;
    }

    
    @RequestMapping("/")
    public String home() {
        return "index";
    }

    @RequestMapping("/doctorlog")
    public String doctorlog() {
        return "logdoct";
    }

    @RequestMapping("/paitentlog")
    public String paitentlog() {
        return "logpet";
    }

    @GetMapping("/registerdo")
    public String showRegistrationPage2(Model model) {
        model.addAttribute("user", new User());
        return "regdoct";
    }

    @GetMapping("/infos")
    public String getMethodName() {
        return "info";
    }

    @GetMapping("/registerpe")
    public String showRegistrationPage1(Model model) {
        model.addAttribute("user", new User());
        return "regpet";
    }

    // @RequestMapping("/home")
    // public String dash(Principal principal,Model model){
    // if(principal != null){
    // String name = principal.getName();
    // String[] nameParts = name.split("@");
    // String firstName = nameParts[0]; // Extract the first part before '@'
    // model.addAttribute("name", firstName.toUpperCase());
    // }
    // return "dash";
    // }
    @GetMapping("/home")
    public String homeRedirect(Authentication auth, Principal principal, Model model, HttpSession session) {
        if (principal != null) {
            String name = principal.getName();
            session.setAttribute("name", name);
            String[] nameParts = name.split("@");
            String firstName = nameParts[0]; // Extract the first part before '@'
            session.setAttribute("firstName", firstName);
            model.addAttribute("name", firstName.toUpperCase());
        }
        if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_DOCTOR"))) {
            model.addAttribute("name", session.getAttribute("firstName"));
            return "dash";
        } else if (auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_PATIENT"))) {
            model.addAttribute("name", session.getAttribute("firstName"));
            Optional<Info> info = infoRepository.findById((String) session.getAttribute("name"));
            if(!info.isEmpty()){
                Info i = info.get();
                model.addAttribute("qrPath", i.getQrCodePath());
            }
            return "petdash";
        } else {
            return "access-denied";
        }
    }

    @PostMapping("/generate")
    public String generateQR(@RequestParam("info") String info, Model model) {
        this.lastInput = info;
        model.addAttribute("info", info);
        return "redirect:/show-qr";
    }

    @GetMapping("/show-qr")
    public String showQRPage(Model model) {
        model.addAttribute("info", lastInput);
        return "show-qr";
    }

    @GetMapping("/qr-image")
    public String getQRImagePage(HttpSession session,Model model) {
        model.addAttribute("name", session.getAttribute("firstName"));
        Optional<Info> info = infoRepository.findById((String) session.getAttribute("name"));
        if(!info.isEmpty()){
            Info i = info.get();
            model.addAttribute("qrPath", i.getQrCodePath());
        }
        return "petdash";
    }
    @GetMapping(value = "/qr-image", produces = MediaType.IMAGE_PNG_VALUE)
    @ResponseBody
    public byte[] getQRImage() throws WriterException, IOException {
        return QRCodeGenerator.generateQRCodeImage(lastInput);
    }
    // @RequestMapping("/paitentregis")
    // public String paitentregis(){
    // return "paitentreigster";
    // }

    // @RequestMapping("/redtest")
    // public String redtest(){
    // return "patientlog";
    // }

    @PostMapping("/registerByPet")
    public String registerUser1(@ModelAttribute User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole("ROLE_PATIENT");
        ur.save(user);
        return "logpet";
    }

    @PostMapping("/registerByDoct")
    public String registerUser2(@ModelAttribute User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole("ROLE_DOCTOR");
        ur.save(user);
        return "logpet";
    }

    @PostMapping("/submit")
    public String generateFullQr(
            @RequestParam String email,
            @RequestParam String fullName,
            @RequestParam String dob,
            @RequestParam String gender,
            @RequestParam String phoneNumber,
            @RequestParam double height,
            @RequestParam double weight,
            @RequestParam(required = false) String bmi,
            @RequestParam(required = false) Integer systolic,
            @RequestParam(required = false) Integer diastolic,
            @RequestParam(required = false) Integer pulseRate,
            @RequestParam(required = false) Double temperature,
            @RequestParam(required = false) Integer bloodSugar,
            @RequestParam(required = false) Integer cholesterol,
            @RequestParam String bloodType,
            @RequestParam(required = false) String allergies,
            @RequestParam(required = false) String currentMedications,
            @RequestParam(required = false) String pastConditions,
            @RequestParam(required = false) String familyHistory,
            @RequestParam(required = false) String smoking,
            @RequestParam(required = false) String alcohol,
            @RequestParam(required = false) String exercise,
            @RequestParam(required = false) String diet,
            Model model) {

        // Construct JSON string
        String json = String.format("""
            {
              "email"             : "%s",
              "fullName"          : "%s",
              "dob"               : "%s",
              "gender"            : "%s",
              "phoneNumber"       : "%s",
              "height"            : %.2f,
              "weight"            : %.2f,
              "bmi"               : "%s",
              "bloodPressure"     : "%s/%s",
              "pulseRate"         : %s,
              "temperature"       : %s,
              "bloodSugar"        : %s,
              "cholesterol"       : %s,
              "bloodType"         : "%s",
              "allergies"         : "%s",
              "currentMedications": "%s",
              "pastConditions"    : "%s",
              "familyHistory"     : "%s",
              "smoking"           : "%s",
              "alcohol"           : "%s",
              "exercise"          : "%s",
              "diet"              : "%s"
            }
            """,
            email, fullName, dob, gender, phoneNumber,
            height, weight, bmi != null ? bmi : "",
            systolic != null ? systolic : "", diastolic != null ? diastolic : "",
            pulseRate != null ? pulseRate : "",
            temperature != null ? temperature : "",
            bloodSugar != null ? bloodSugar : "",
            cholesterol != null ? cholesterol : "",
            bloodType,
            sanitize(allergies),
            sanitize(currentMedications),
            sanitize(pastConditions),
            sanitize(familyHistory),
            smoking != null ? smoking : "",
            alcohol != null ? alcohol : "",
            exercise != null ? exercise : "",
            diet != null ? diet : ""
        );
        


        try {
            String qrPath = QrCodeUtil.generateQRCode(json, email);

            Optional<Info> i = infoRepository.findById(email);
            if (i.isPresent()) {
                Info existingInfo = i.get();
                String existingQrPath = existingInfo.getQrCodePath();
                Qrdel(existingQrPath);
                infoRepository.delete(existingInfo);  
            }
            Info info = new Info();
                info.setEmail(email);
                info.setQrCodePath(qrPath);
                info.setDetails(json);
                infoRepository.save(info);
            return "petdash";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to generate QR Code.");
            return "error";
        }
    }

    private String sanitize(String input) {
        return input != null ? input.replace("\"", "'").replace("\n", " ") : "";
    }

    public void Qrdel(String qrPath) {
        String mainpath = "src/main/resources/static/" + qrPath;
        try {
            //Path path = Paths.get(new ClassPathResource(mainpath).getURI());
            Path path = Paths.get(mainpath);
            Files.deleteIfExists(path);
        } catch (Exception e) {
            System.out.println("Error deleting existing QR code: " + e.getMessage());
        }
    }

}
