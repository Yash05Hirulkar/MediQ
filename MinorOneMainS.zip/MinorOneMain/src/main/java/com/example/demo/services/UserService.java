package com.example.demo.services;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Control.FirstControl;
import com.example.demo.Entities.Prescription;
import com.example.demo.Entities.User;
import com.example.demo.repository.PrescriptionRepository;
import com.example.demo.repository.UserRepository;

import jakarta.annotation.PostConstruct;

@Service
public class UserService{
    private final UserRepository userRepository;
    private final PrescriptionRepository prescriptionRepository;

    @Autowired
    public FirstControl firstControl;
    //private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, PrescriptionRepository prescriptionRepository) {
        this.userRepository = userRepository;
        //this.passwordEncoder = passwordEncoder;
        this.prescriptionRepository = prescriptionRepository;
    }

//    public User saveUser(User user) {
//        user.setPassword(passwordEncoder.encode(user.getPassword()));
//        System.out.println("user saved successfully.....");
//        return userRepository.save(user);
//    }


    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
// when the application starts, it will delete all expired prescriptions
    @PostConstruct
    public void delete(){
        System.out.println("Deleting old prescriptions...");
        deleevry();
    }

    public void deleevry(){
        LocalDateTime currentDateTime = LocalDateTime.now();
        List<Prescription> expiredPrescriptions = prescriptionRepository.findByDateOfExpiryBefore(currentDateTime);
        expiredPrescriptions.stream()
        .forEach(prescription -> firstControl.Qrdel(prescription.getQrCodePath()));
        prescriptionRepository.deleteAll(expiredPrescriptions);
        System.out.println("Deleted expired prescriptions: " + expiredPrescriptions.size());
        

    }
}